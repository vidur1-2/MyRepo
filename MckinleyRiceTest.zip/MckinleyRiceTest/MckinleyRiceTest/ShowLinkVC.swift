//
//  ShowLinkVC.swift
//  MckinleyRiceTest
//
//  Created by Vidur on 04/04/20.
//  Copyright © 2020 None. All rights reserved.
//

import UIKit

class ShowLinkVC: UIViewController,UIWebViewDelegate{

    var urlStr = "https://mckinleyrice.com/?token=\(SaveToDefaults().getToken()!)"
    //var urlStr = "https://mckinleyrice.com?token=\(SaveToDefaults().getToken()!)"
    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("url",urlStr)
        webView.delegate = self
              let url = URL.init(string: urlStr)
              let requestObj = URLRequest(url: url!)
              webView.loadRequest(requestObj)
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           self.webView = nil
       }
}
