//
//  ShowUrlVC.swift
//  MckinleyRiceTest
//
//  Created by Vidur on 04/04/20.
//  Copyright © 2020 None. All rights reserved.
//

import UIKit

class ShowUrlVC: UIViewController {

    @IBOutlet weak var passwordTextfeild: UITextField!
       @IBOutlet weak var idTextfeiold: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func loginBtnAction(_ sender: UIButton) {
           print("jkdhfkjd")
        self.hitLoginApi()
       
       }
    
    func hitLoginApi(){
        let param : [String : Any] = ["email" : self.idTextfeiold.text!,"password" : self.passwordTextfeild.text!]
           print(param)
               api_manager.POSTApi(signUpUrl(), param: param, header: nil) { (response, error, statuscode) in
                   if let error = error {
                       print(error.localizedDescription)
                   }
                   else if let json = response{
                    print(json)
                    SaveToDefaults().setToken(time: json["token"].stringValue)
                    let vc = ShowLinkVC.storyboardInstance()
                    self.navigationController?.pushViewController(vc!, animated: true)
                   }else{
                      
                   }
               }
       }

}
