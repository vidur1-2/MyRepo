//
//  ApiManager.swift
//  VideoChat
//
//  Created by preeti rani on 06/03/17.
//  Copyright © 2017 Innotical. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

extension JSON{
    func isKeyPresent()->Bool {
        if self == nil || self.null != nil{
            return false
        }
        return true
    }
}

let api_manager = ApiManager.sharedInstance

public protocol JSONDecodable{
    init(json:JSON)
}

extension Collection where Iterator.Element == JSON {
    func decode<T:JSONDecodable>() -> [T] {
        return map({T(json:$0)})
    }
}

class ApiManager {
    static let sharedInstance = ApiManager.init()
    
    func POSTApi(_ url: String, param: [String: Any]?, header : [String : String]?,  completion:@escaping (_ jsonData:JSON? , _ error:Error?, _ statuscode : Int? )->()) {
        
        print("Header------>>>>>",header ?? "")
        print("Param------>>>>>",param ?? "")
       
        _ =  Alamofire.request(url, method: .post, parameters: param , encoding: JSONEncoding.default, headers: header).responseJSON{ (dataResponse) in
            
            debugPrint(dataResponse.timeline)
            guard dataResponse.result.isSuccess else {
                let error = dataResponse.result.error!
                print("POSTApi Error : ",error )
                completion(nil , error , nil)
                return
            }
            if dataResponse.result.value != nil{
                let json = JSON.init(dataResponse.result.value!)
                 print("jsonData------>>>>>",json)
                DispatchQueue.main.async {
                    
                }
                completion(json , nil, dataResponse.response?.statusCode)
            }else{
                DispatchQueue.main.async {
                    
                }
                completion(nil , nil,dataResponse.response?.statusCode)
            }
            print("POSTApi statuscode : ",dataResponse.response?.statusCode ?? "")
        }
    }
    
    func GETApi(_ url: String , param: [String: Any]?, header : [String : String]? , completion:@escaping (_ jsonData:JSON? , _ error:Error?, _ statuscode : Int?)->()){
        Alamofire.request(url, method: .get, parameters: param, encoding:JSONEncoding.default, headers: header)
            .responseJSON { (dataResponse) in
                debugPrint(dataResponse.timeline)
                guard dataResponse.result.isSuccess else {
                    let error = dataResponse.result.error!
                    print("GETApi Error : ",error )
                    completion(nil , error, dataResponse.response?.statusCode)
                    return
                }
                if dataResponse.result.value != nil{
                    let json = JSON.init(dataResponse.result.value!)
                    print(json)
                    DispatchQueue.main.async {
                        
                    }
                    completion(json , nil,dataResponse.response?.statusCode)
                }else{
                    DispatchQueue.main.async {
                        
                    }
                    completion(nil , nil,dataResponse.response?.statusCode)
                }
                print("GETApi statuscode : ",dataResponse.response?.statusCode ?? "")
        }
      }
   
    
    func PUTApi(_ url: String , param: [String: Any]?, header : [String : String]? , completion:@escaping (_ jsonData:JSON? , _ error:Error?, _ statuscode : Int?)->()){
        Alamofire.request(url, method: .put, parameters: param, encoding:JSONEncoding.default, headers: header)
            .responseJSON { (dataResponse) in
                debugPrint(dataResponse.timeline)
                guard dataResponse.result.isSuccess else {
                    let error = dataResponse.result.error!
                    print("PUTApi Error : ",error )
                    DispatchQueue.main.async {
                        
                    }
                    completion(nil , error, dataResponse.response?.statusCode)
                    return
                }
                if dataResponse.result.value != nil{
                    let json = JSON.init(dataResponse.result.value!)
                    DispatchQueue.main.async {
                        
                    }
                    completion(json , nil,dataResponse.response?.statusCode)
                }else{
                    DispatchQueue.main.async {
                        
                    }
                    completion(nil , nil,dataResponse.response?.statusCode)
                }
                print("GETApi statuscode : ",dataResponse.response?.statusCode ?? "")
        }
    }
    
    func DELETEApi(_ url: String , param: [String: Any]?, header : [String : String]? , completion:@escaping (_ jsonData:JSON? , _ error:Error?, _ statuscode : Int?)->()){
        Alamofire.request(url, method: .delete, parameters: param, encoding:JSONEncoding.default, headers: header)
            .responseJSON { (dataResponse) in
                debugPrint(dataResponse.timeline)
                guard dataResponse.result.isSuccess else {
                    let error = dataResponse.result.error!
                    print("GETApi Error : ",error )
                    DispatchQueue.main.async {
                        
                    }
                    
                    completion(nil , error, dataResponse.response?.statusCode)
                    return
                }
                if dataResponse.result.value != nil{
                    let json = JSON.init(dataResponse.result.value!)
                    DispatchQueue.main.async {
                        
                    }
                    completion(json , nil,dataResponse.response?.statusCode)
                }else{
                    DispatchQueue.main.async {
                        
                    }
                    completion(nil , nil,dataResponse.response?.statusCode)
                }
                print("GETApi statuscode : ",dataResponse.response?.statusCode ?? "")
        }
    }
    

    func UploadEventImage(_ url :String , _ data:Data, _ fileName:String , _ event_id:String , header:[String:String]? , completion:@escaping (_ error:Error? , _ responce:Any?,_ statuscode :Int?)->())  {
        Alamofire.upload(multipartFormData:{ multipartFormData in
            multipartFormData.append(data, withName: "image", fileName: fileName, mimeType: "*/*")
            let data = event_id.data(using:.utf8)
            multipartFormData.append(data!, withName: "event_id")
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:.post,
                         headers:header,
                         encodingCompletion: { encodingResult in
                            switch encodingResult {
                            case .success(let upload, _, _):
                                upload.responseJSON { response in
                                    debugPrint(response)
                                    guard response.result.isSuccess else {
                                        let error = response.result.error
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(error , nil,response.response?.statusCode)
                                        return
                                    }
                                    if response.result.value != nil{
                                        let json = JSON.init(response.result.value!)
                                        DispatchQueue.main.async {
                                            
                                        }
                                        
                                        completion(nil , json,response.response?.statusCode)
                                    }else{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        
                                        completion(nil , nil,response.response?.statusCode)
                                    }
                                }
                            case .failure(let encodingError):
                                print(encodingError)
                                DispatchQueue.main.async {
                                    
                                }
                                completion(encodingError , nil,nil)
                            }
        })
    }

    
    func UPLOADTeamLogo(_ url :String , _ data:Data, _ fileName:String , header:[String:String]? , completion:@escaping (_ error:Error? , _ responce:Any?,_ statuscode :Int?)->())  {
        Alamofire.upload(multipartFormData:{ multipartFormData in
            multipartFormData.append(data, withName: "image", fileName: fileName, mimeType: "*/*")
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:.put,
                         headers:header,
                         encodingCompletion: { encodingResult in
                            switch encodingResult {
                            case .success(let upload, _, _):
                                upload.responseJSON { response in
                                    debugPrint(response)
                                    guard response.result.isSuccess else {
                                        let error = response.result.error
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(error , nil,response.response?.statusCode)
                                        return
                                    }
                                    if response.result.value != nil{
                                        let json = JSON.init(response.result.value!)
                                        DispatchQueue.main.async {
                                            
                                        }
                                        
                                        completion(nil , json,response.response?.statusCode)
                                    }else{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        
                                        completion(nil , nil,response.response?.statusCode)
                                    }
                                }
                            case .failure(let encodingError):
                                print(encodingError)
                                DispatchQueue.main.async {
                                    
                                }
                                completion(encodingError , nil,nil)
                            }
        })
    }
    
    
    func loadImage(_ url:String)  ->UIImage?{
        var image:UIImage?
        print(url)
        Alamofire.download(url)
            .downloadProgress { progress in
                print("Download Progress: \(progress.fractionCompleted)")
            }
            .responseData { response in
                if let data = response.result.value {
                    image =  UIImage(data: data)
                }
        }
        return image
    }

    
    func local(_ url: String , param: [String: Any]?, header : [String : String]? , completion:@escaping (_ jsonData:JSON? , _ error:Error?, _ statuscode : Int?)->()){
        
        let config = URLSessionConfiguration.default
        
        let url = URL(string: url)!
        var request = URLRequest(url: url)
        if let value = header?["Authorization"] {
            print(value)
            config.httpAdditionalHeaders = ["Authorization" : value]
            request.setValue(value, forHTTPHeaderField: "Authorization")
        }
        request.httpMethod = "GET"
        print(request.value(forHTTPHeaderField: "Authorization") ?? "NiL")
        let session = URLSession.init(configuration: config)
        let tache = session.dataTask(with: request) { (dataaa, response, error) -> Void in
            if let antwort = response as? HTTPURLResponse {
                let code = antwort.statusCode
                print(code)
            }
            if let data = dataaa{
               // let json = JSON.init(data: data)
               // print(json)
            }
        }
        
        tache.resume()
    }
    
    
    func PostWorkoutApi(_ url :String ,_ data:Data?, _ fileName:String? , paremes:[String:Any]? , header:[String:String]?, completion:@escaping (_ error:Error? , _ responce:Any?,_ statuscode :Int?)->())  {
        
        Alamofire.upload(multipartFormData:{ multipartFormData in
            multipartFormData.append(data ?? Data(), withName: "workout_image", fileName: fileName ?? "", mimeType: "*/*")
            
            if let param = paremes{
                print(param)
                let name = (param["name"] as! String).data(using:.utf8)
                multipartFormData.append(name!, withName: "name")
                
                let adhaar_no = (param["exercise"] as! String).data(using:.utf8)
                multipartFormData.append(adhaar_no!, withName: "exercise")
                
                let mobile = (param["description"] as! String).data(using:.utf8)
                multipartFormData.append(mobile!, withName: "description")
                let rest_time = (param["rest_time"] as! String).data(using:.utf8)
                multipartFormData.append(rest_time!, withName: "rest_time")
        
            }
            
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:.post,
                         headers:header,
                         encodingCompletion: { encodingResult in
                            switch encodingResult {
                            case .success(let upload, _, _):
                                upload.responseJSON { response in
                                    debugPrint(response)
                                    guard response.result.isSuccess else {
                                        let error = response.result.error
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(error , nil,response.response?.statusCode)
                                        return
                                    }
                                    if response.result.value != nil{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(nil , response.result.value!,response.response?.statusCode)
                                    }else{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(nil , nil,response.response?.statusCode)
                                    }
                                }
                            case .failure(let encodingError):
                                print(encodingError)
                                completion(encodingError , nil,nil)
                            }
        })
    }
    
    
    
    
    func PostProfileDataApi(_ url :String ,_ data:Data?, _ fileName:String? , paremes:[String:Any]? , header:[String:String]?,isImageTrue : Bool, completion:@escaping (_ error:Error? , _ responce:Any?,_ statuscode :Int?)->())  {
        
        
        Alamofire.upload(multipartFormData:{ multipartFormData in
            if isImageTrue{
            multipartFormData.append(data ?? Data(), withName: "image", fileName: fileName ?? "", mimeType: "*/*")
            }
            else{
            if let param = paremes{
                print(param)
                let gender = (param["gender"] as! String).data(using:.utf8)
                multipartFormData.append(gender!, withName: "gender")
                
                let date_of_birth = (param["date_of_birth"] as! String).data(using:.utf8)
                multipartFormData.append(date_of_birth!, withName: "date_of_birth")
                
                let weight = (param["weight"] as! String).data(using:.utf8)
                multipartFormData.append(weight!, withName: "weight")
                
                let target = (param["target"] as! String).data(using:.utf8)
                multipartFormData.append(target!, withName: "target")
                
                let height = (param["height"] as! String).data(using:.utf8)
                multipartFormData.append(height!, withName: "height")
                
                let goal = (param["goal"] as! String).data(using:.utf8)
                multipartFormData.append(goal!, withName: "goal")
                
                let duration = (param["duration"] as! String).data(using:.utf8)
                multipartFormData.append(duration!, withName: "duration")
            }
            }
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:.post,
                         headers:header,
                         encodingCompletion: { encodingResult in
                            switch encodingResult {
                            case .success(let upload, _, _):
                                upload.responseJSON { response in
                                    debugPrint(response)
                                    guard response.result.isSuccess else {
                                        let error = response.result.error
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(error , nil,response.response?.statusCode)
                                        return
                                    }
                                    if response.result.value != nil{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(nil , response.result.value!,response.response?.statusCode)
                                    }else{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(nil , nil,response.response?.statusCode)
                                    }
                                }
                            case .failure(let encodingError):
                                print(encodingError)
                                completion(encodingError , nil,nil)
                            }
        })
    }
    
    
    
    
    
    func UpdateWorkoutApi(_ url :String ,_ data:Data?, _ fileName:String? , paremes:[String:Any]? , header:[String:String]?, completion:@escaping (_ error:Error? , _ responce:Any?,_ statuscode :Int?)->())  {
        
        Alamofire.upload(multipartFormData:{ multipartFormData in
            multipartFormData.append(data ?? Data(), withName: "workout_image", fileName: fileName ?? "", mimeType: "*/*")
            
            if let param = paremes{
                print(param)
                let name = (param["name"] as! String).data(using:.utf8)
                multipartFormData.append(name!, withName: "name")
                
                let adhaar_no = (param["exercise"] as! String).data(using:.utf8)
                multipartFormData.append(adhaar_no!, withName: "exercise")
                
                let mobile = (param["description"] as! String).data(using:.utf8)
                multipartFormData.append(mobile!, withName: "description")
                
            }
            
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:.put,
                         headers:header,
                         encodingCompletion: { encodingResult in
                            switch encodingResult {
                            case .success(let upload, _, _):
                                upload.responseJSON { response in
                                    debugPrint(response)
                                    guard response.result.isSuccess else {
                                        let error = response.result.error
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(error , nil,response.response?.statusCode)
                                        return
                                    }
                                    if response.result.value != nil{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(nil , response.result.value!,response.response?.statusCode)
                                    }else{
                                        DispatchQueue.main.async {
                                            
                                        }
                                        completion(nil , nil,response.response?.statusCode)
                                    }
                                }
                            case .failure(let encodingError):
                                print(encodingError)
                                completion(encodingError , nil,nil)
                            }
        })
    }
}

