
import Foundation
import UIKit

let onboarding = UIStoryboard.init(name: "Onboarding", bundle: nil)


extension ShowUrlVC{
    class func storyboardInstance()-> ShowUrlVC?{
        return onboarding.instantiateViewController(withIdentifier: "ShowUrlVC") as? ShowUrlVC
    }
    
    class func navigation()-> UINavigationController?{
        return onboarding.instantiateViewController(withIdentifier: "onboarding") as? UINavigationController
    }
}

extension ShowLinkVC{
    class func storyboardInstance()-> ShowLinkVC?{
        return onboarding.instantiateViewController(withIdentifier: "ShowLinkVC") as? ShowLinkVC
    }
}
