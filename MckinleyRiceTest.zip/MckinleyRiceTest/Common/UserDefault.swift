//
//  UserDefault.swift
//  MySwaasthNew
//
//  Created by preeti rani on 28/04/17.
//  Copyright © 2017 Innotical. All rights reserved.
//

import Foundation

let defaults = UserDefaults.standard

enum ProfileInfoKeys : String {
    case token
    case dob
    case weight
  
    
}
struct SaveToDefaults {
    
    func setToken(time : String) {
        defaults.set(time, forKey: ProfileInfoKeys.token.rawValue)
    }
    
    func getToken() -> String? {
        return defaults.value(forKey: ProfileInfoKeys.token.rawValue) as? String
    }
}



